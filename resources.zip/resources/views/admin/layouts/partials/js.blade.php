        <script src="{{ asset('admin/assets/js/jquery-3.2.1.min.js') }}"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="{{ asset('admin/assets/js/popper.min.js') }}"></script>
        <script src="{{ asset('admin/assets/js/bootstrap.min.js') }}"></script>
		
		<!-- Slimscroll JS -->
        <script src="{{ asset('admin/assets/plugins/slimscroll/jquery.slimscroll.min.js') }}"></script>
		
		<script src="{{ asset('admin/assets/plugins/raphael/raphael.min.js') }}"></script>    
		<script src="{{ asset('admin/assets/plugins/morris/morris.min.js') }}"></script>  
		<script src="{{ asset('admin/assets/js/chart.morris.js') }}"></script>
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		
		<!-- Custom JS -->
		<script  src="{{ asset('admin/assets/js/script.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/customadmin.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/category.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/tag.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/post.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/jquery.tagselect.js') }}"></script>
		<script  src="{{ asset('admin/assets/js/image-uploader.js') }}"></script>
