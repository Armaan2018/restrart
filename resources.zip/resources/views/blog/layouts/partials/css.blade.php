      <link href="{{ asset('blog/assets/img/favicon.png') }}" rel="icon">
      <link rel="stylesheet" href="{{ asset('blog/assets/css/bootstrap.min.css') }}">
      <link rel="stylesheet" href="{{ asset('blog/assets/plugins/fontawesome/css/fontawesome.min.css') }}">
      <link rel="stylesheet" href="{{ asset('blog/assets/plugins/fontawesome/css/all.min.css') }}">
      <link rel="stylesheet" href="{{ asset('blog/assets/css/style.css') }}">
      <link rel="stylesheet" href="{{ asset('blog/assets/css/customblog.css') }}">
      <!--[if lt IE 9]>
      <script src="blog/assets/js/html5shiv.min.js"></script>
      <script src="blog/assets/js/respond.min.js"></script>
      <![endif]-->