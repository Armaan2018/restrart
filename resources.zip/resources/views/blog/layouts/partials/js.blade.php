      <script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="{{ asset('blog/assets/js/jquery.min.js') }}"></script>
      <script src="{{ asset('blog/assets/js/popper.min.js') }}"></script>
      <script src="{{ asset('blog/assets/js/bootstrap.min.js') }}"></script>
      <script src="{{ asset('blog/assets/plugins/theia-sticky-sidebar/ResizeSensor.js') }}"></script>
      <script src="{{ asset('blog/assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js') }}"></script>
      <script src="{{ asset('blog/assets/js/script.js') }}"></script>