<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from doccure-html.dreamguystech.com/template/blog-grid.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 Oct 2021 06:32:23 GMT -->
   <head>
      <meta charset="utf-8">
      <title>Doccure</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">


          <?php echo $__env->make('blog.layouts.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   </head>
   <body>
      <div class="main-wrapper">

         <?php echo $__env->make('blog.layouts.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

         <div class="breadcrumb-bar">
            <div class="container-fluid">
               <div class="row align-items-center">
                  <div class="col-md-12 col-12">
                     <nav aria-label="breadcrumb" class="page-breadcrumb">
                        <ol class="breadcrumb">
                           <li class="breadcrumb-item"><a href="<?php echo e(route('blog')); ?>">Home</a></li>
                           <li class="breadcrumb-item active" aria-current="page">Blog</li>
                        </ol>
                     </nav>
                     <h2 class="breadcrumb-title">Blog Grid</h2>
                  </div>
               </div>
            </div>
         </div>


         <div class="content">
            <div class="container">
               <div class="row">
                  <div class="col-lg-8 col-md-12">
                     <div class="row blog-grid-row">
                
                <?php $__env->startSection('main-content-blog'); ?>
                <?php echo $__env->yieldSection(); ?>


                     </div>
                  

           


                  </div>
        <?php echo $__env->make('blog.layouts.parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
            </div>
         </div>
    <?php echo $__env->make('blog.layouts.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
    <?php echo $__env->make('blog.layouts.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
   <!-- Mirrored from doccure-html.dreamguystech.com/template/blog-grid.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 31 Oct 2021 06:32:23 GMT -->
</html><?php /**PATH C:\xampp\htdocs\restart2.0\resources\views/blog/layouts/app.blade.php ENDPATH**/ ?>