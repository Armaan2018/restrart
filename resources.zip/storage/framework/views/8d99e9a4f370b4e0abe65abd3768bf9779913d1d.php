                  <div class="col-lg-4 col-md-12 sidebar-right theiaStickySidebar">
                     <div class="card search-widget">
                        <div class="card-body">



                           <form class="search-form" method="POST" action="<?php echo e(route('blog.search.sidebar')); ?>">
                            <?php echo csrf_field(); ?>
                              <div class="input-group">
                                 <input type="text" name="searchname" placeholder="Search..." class="form-control">
                                 <div class="input-group-append">
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
                                 </div>
                              </div>
                           </form>


                        </div>
                     </div>
                     <div class="card post-widget">
                        <div class="card-header">
                           <h4 class="card-title">Latest Posts</h4>
                        </div>
                        <div class="card-body">
                           <ul class="latest-posts">


                    <?php $__currentLoopData = $sidebarpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php
                               $post_type = json_decode($element -> featured)
                             ?>

                             <?php if($post_type -> format == 'image'): ?>

                    

                                 <li>
                                 <div class="post-thumb">
                                    <a href="<?php echo e(route('blog.single',$element-> slug)); ?>">
                                    <img class="img-fluid" src="<?php echo e(URL::to('')); ?>/media/post/<?php echo e($post_type -> image); ?>" alt=""> 
                                    </a>
                                 </div>
                                 <div class="post-info">
                                    <h4>
                                       <a href="<?php echo e(route('blog.single',$element-> slug)); ?>"><?php echo Str::of(htmlspecialchars($element -> title))->words(20); ?></a>
                                    </h4>
                                    <p><?php echo e(date("d F, Y")); ?></p>
                                 </div>
                              </li>
                                       <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                           </ul>
                        </div>
                     </div>
                     <div class="card category-widget">
                        <div class="card-header">
                           <h4 class="card-title">Blog Categories (<?php echo e($catno); ?>)</h4>
                        </div>
                        <div class="card-body">
                           <ul class="categories">
                              <?php $__currentLoopData = $catall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <li><a href="<?php echo e(route('blog.cat.search',$cat -> slug)); ?>"><?php echo e($cat -> name); ?> <span>(<?php echo e($catno); ?>)</span></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             

                           </ul>
                        </div>
                     </div>
                     <div class="card tags-widget">
                        <div class="card-header">
                           <h4 class="card-title">Tags (<?php echo e($tagno); ?>)</h4>
                        </div>
                        <div class="card-body">
                           <ul class="tags">
                              <?php $__currentLoopData = $tagall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagsingle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('blog.tag.search',$tagsingle -> slug)); ?>" class="tag"> <?php echo e($tagsingle -> name); ?></a></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              

                           </ul>
                        </div>
                     </div>
                  </div><?php /**PATH C:\xampp\htdocs\restart2.0\resources\views/blog/layouts/parts/sidebar.blade.php ENDPATH**/ ?>