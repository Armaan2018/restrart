      <link href="<?php echo e(asset('blog/assets/img/favicon.png')); ?>" rel="icon">
      <link rel="stylesheet" href="<?php echo e(asset('blog/assets/css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('blog/assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('blog/assets/plugins/fontawesome/css/all.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('blog/assets/css/style.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('blog/assets/css/customblog.css')); ?>">
      <!--[if lt IE 9]>
      <script src="blog/assets/js/html5shiv.min.js"></script>
      <script src="blog/assets/js/respond.min.js"></script>
      <![endif]--><?php /**PATH C:\xampp\htdocs\restart2.0\resources\views/blog/layouts/partials/css.blade.php ENDPATH**/ ?>