		


<?php $__env->startSection('main-content'); ?>
		<!-- Main Wrapper -->
        <div class="main-wrapper login-body">
            <div class="login-wrapper">
            	<div class="container">
                	<div class="loginbox">
                    	<div class="login-left">
							<img class="img-fluid" src="<?php echo e(asset('admin/assets/img/logo-white.png')); ?>" alt="Logo">
                        </div>
                        <div class="login-right">
							<div class="login-right-wrap">
								<h1>Register</h1>
								<p class="account-subtitle">Access to our dashboard</p>
								
								<!-- Form -->
								<form action="<?php echo e(route('admin.register')); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<div class="form-group">
										<input class="form-control" name="name"  type="text" placeholder="Name">
										
									</div>
									<div class="form-group">
										<input class="form-control" name="email" type="text" placeholder="Email">
									</div>	

									<div class="form-group">
										<input class="form-control" name="username" type="text" placeholder="username">
									</div>	

									<div class="form-group">
										<input class="form-control" name="phone_number" type="text" placeholder="Phone">
									</div>
									<div class="form-group">
										<input class="form-control" name="password" type="password" placeholder="Password">
									</div>
									<div class="form-group">
										<input class="form-control" name="password_confirmation" type="password" placeholder="Confirm Password">
									</div>
									<div class="form-group mb-0">
										<button class="btn btn-primary btn-block" type="submit">Register</button>
									</div>
								</form>
								<!-- /Form -->
								
								<div class="login-or">
									<span class="or-line"></span>
									<span class="span-or">or</span>
								</div>
								
								<!-- Social Login -->
								<div class="social-login">
									<span>Register with</span>
									<a href="#" class="facebook"><i class="fa fa-facebook"></i></a><a href="#" class="google"><i class="fa fa-google"></i></a>
								</div>
								<!-- /Social Login -->
								
								<div class="text-center dont-have">Already have an account? <a href="<?php echo e(route('admin-login')); ?>">Login</a></div>
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!-- /Main Wrapper -->


		<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restart2.0\resources\views/admin/register.blade.php ENDPATH**/ ?>