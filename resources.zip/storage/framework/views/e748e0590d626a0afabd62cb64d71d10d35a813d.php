



<?php $__env->startSection('main-content-blog'); ?>

<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
   $post_type = json_decode($element -> featured)	
?>

    <?php if($post_type -> format == 'image'): ?>
                        <div class="col-md-6 col-sm-12">
                           <div class="blog grid-blog">

                      


                              <div class="blog-image">
                                 <a href="<?php echo e(route('blog.single',$element-> slug)); ?>"><img class="img-fluid" src="<?php echo e(URL::to('')); ?>/media/post/<?php echo e($post_type -> image); ?>" alt="Post Image"></a>

                              </div>


             

                              <div class="blog-content">
                                 <ul class="entry-meta meta-item">

                                    <li><i class="far fa-clock mr-1"></i><?php echo e(date("d F, Y")); ?></li>
                                   
                                    <li> 
                                    <?php $__currentLoopData = $element -> categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="doctor-profile.html" class="btn view-btn p-1" tabindex="-1"><?php echo e($cat -> name); ?></a>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                    	
                                    </li>


                                 </ul>
                                 <h3 class="blog-title"><a href="<?php echo e(route('blog.single',$element-> slug)); ?>"><?php echo e($element -> title); ?></a></h3>
                                 <p class="mb-0"><?php echo Str::of(htmlspecialchars($element -> content))->words(15); ?><a href="<?php echo e(route('blog.single',$element-> slug)); ?>" class="text-danger">Read More</a></p>

                                    <ul class="entry-meta meta-item mt-3">
                                    <li><i class="far fa-user-circle mr-1"></i><?php $__currentLoopData = $element -> users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($userdetail -> name); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                                   
                                    <li> 
                                    <?php $__currentLoopData = $element -> tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span  class="badge badge-primary" tabindex="-1"><?php echo e($tag -> name); ?></span>


                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                    	
                                    </li>


                                 </ul>
                              </div>
                           </div>
                        </div>



                        

                                     <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<div class="container">
	      
	      <?php echo e($post->links('blog.layouts.partials.paginator')); ?>

          
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restart2.0\resources\views/blog/blog-search.blade.php ENDPATH**/ ?>